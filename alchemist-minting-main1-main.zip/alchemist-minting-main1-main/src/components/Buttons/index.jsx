import "./index.scss";
import PrimaryButton from "./PrimaryButton";
import SecondaryButton from "./SecondaryButton";

export { PrimaryButton, SecondaryButton };
