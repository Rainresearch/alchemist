import { createContext } from 'react';

const MintAmount = createContext();
export default MintAmount;